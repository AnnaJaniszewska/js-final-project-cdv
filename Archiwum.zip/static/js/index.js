function roundOrangeLeft(){
    document.getElementById("roundleftIMG").src = "static/assets/roundorange.png"
    document.getElementById("roundrightIMG").src = "static/assets/round.png"

}

function roundOrangeRight(){
    document.getElementById("roundrightIMG").src = "static/assets/roundorange.png"
    document.getElementById("roundleftIMG").src = "static/assets/round.png"
}

function cleanselected(){
    document.getElementById("roundrightIMG").src = "static/assets/round.png"
    document.getElementById("roundleftIMG").src = "static/assets/round.png"
}